<?php 
/*	$a = json_decode($_POST["name"]);
	$a = "hello";
#	echo $a["name"];
#	system.out.println("some")
	$message = "Line 1";

// In case any of our lines are larger than 70 characters, we should use wordwrap()
	$message = wordwrap($message, 70, "\r\n");

// Send
*/
	if ( empty($_POST) ) {
//		$data = [ json_decode($_POST) ];
		$postdata = file_get_contents("php://input");
		$_POST = json_decode(file_get_contents('php://input'), true);
		header('Content-Type: application/json');
		header("HTTP/1.1 200 OK");
		mail('sam@tesla-solutions.com', $_POST['email'], $_POST['name']."(".$_POST['email'].") wrote:\n\n".$_POST['message']);
                sleep(3);
                mail($_POST['email'], "Tesla Solutions", "Thank you for contacting us, we will get back to you shortly.\n\nYour message:\n\n".$_POST['message']."\n\nPlease do not reply to this email.\n\n-----\nTesla Solutions\n(408)597-6245");
//		echo json_encode($postdata);
		echo json_encode($_POST["email"]);
	} else {
		echo "BRR";
	}
?>
