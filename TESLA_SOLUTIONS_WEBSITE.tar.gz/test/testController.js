app.controller('testController', ['$scope', function($scope){
    $scope.barabum="bam"
}]);
